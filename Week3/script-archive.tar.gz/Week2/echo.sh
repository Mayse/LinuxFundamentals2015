#!/bin/bash
echo "$*"

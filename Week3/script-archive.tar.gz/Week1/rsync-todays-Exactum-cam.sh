#!/bin/bash
echo "rsync --archive /home/fs/tkt_cam/public_html/`date +%m`/`date +%d` ~/LinuxFundamentals/Week1/`date +%d.%Y.%m.%d`"

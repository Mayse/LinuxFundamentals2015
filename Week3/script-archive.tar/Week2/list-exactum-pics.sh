#!/bin/bash
ls -aR /home/tktl-csfs/home/tkt_cam/public_html/2011/11 | grep '\.jpg$'

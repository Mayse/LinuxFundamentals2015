#!/bin/bash
echo "Today is `date +%m.%d.%Y`"

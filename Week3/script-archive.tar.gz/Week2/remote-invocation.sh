#!/bin/bash
targethost=$1
targetcommand=$2
ssh $1 $2
